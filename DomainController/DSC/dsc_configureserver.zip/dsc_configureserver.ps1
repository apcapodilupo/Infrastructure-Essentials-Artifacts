﻿configuration configureServer 
{ 
   param 
   ( 

        
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Node localhost
    {

           # The first resource block ensures that the Web-Server (IIS) feature is enabled.

        WindowsFeature WebServer {
            Ensure = "Present"
            Name   = "Web-Server"
        }

   }
} 